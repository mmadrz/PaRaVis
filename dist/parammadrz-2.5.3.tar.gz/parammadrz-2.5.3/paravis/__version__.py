"""Version information for PaRaVis."""

__version__ = "2.0.1"
__version_info__ = (2, 0, 1)
