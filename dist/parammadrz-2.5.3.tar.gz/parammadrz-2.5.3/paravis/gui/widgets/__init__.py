"""GUI panel widgets."""
