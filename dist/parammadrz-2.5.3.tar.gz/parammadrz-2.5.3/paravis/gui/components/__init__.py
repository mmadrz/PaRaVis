"""Reusable GUI components."""
